#ifndef SERVER_H
#define SERVER_H

#include "wen.c"

#endif